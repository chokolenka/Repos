CREATE TABLE firm (
                       id int NOT NULL AUTO_INCREMENT,
                       name varchar(45),
                       PRIMARY KEY (id)
);

CREATE TABLE os (
                      id int NOT NULL AUTO_INCREMENT,
                      name varchar(45),
                      developer varchar(45),
                      PRIMARY KEY (id)
);

CREATE TABLE smartphone (
                            id int NOT NULL AUTO_INCREMENT,
                             firm_id int NOT NULL,
                             os_id int NOT NULL,
                             size float,
                             color text,
                             PRIMARY KEY (id),
                             CONSTRAINT role_fk FOREIGN KEY (firm_id) REFERENCES firm (id),
                             CONSTRAINT user_fk FOREIGN KEY (os_id) REFERENCES os (id)
);