package com.company.spring_thymeleaf_form.os;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OsRepository extends JpaRepository<Os, Long> {
}


