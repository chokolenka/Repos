package com.company.spring_thymeleaf_form.firms;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FirmRepository extends JpaRepository<Firm, Long> {
}


