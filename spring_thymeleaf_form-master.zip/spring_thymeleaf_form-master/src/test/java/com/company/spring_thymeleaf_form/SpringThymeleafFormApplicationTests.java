package com.company.spring_thymeleaf_form;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringThymeleafFormApplicationTests {

    @Test
    void contextLoads() {
    }

}
