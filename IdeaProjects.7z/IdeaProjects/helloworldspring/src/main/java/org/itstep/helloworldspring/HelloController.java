package org.itstep.helloworldspring;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    @RequestMapping("/")// отображение запроса
    public String hello(){
        return "Hello, world!";
    }

    @RequestMapping("/bye")// отображение запроса
    public String bye(){
        return "bye";
    }

}
