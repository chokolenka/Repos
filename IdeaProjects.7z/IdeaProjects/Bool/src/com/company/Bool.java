package com.company;

public class Bool {

    public static void main(String[] args) {
	// Проверить истинность высказывания: «Среди трех данных целых
		//чисел есть хотя бы одна пара совпадающих».
		int a=4, b=2, c=2;
		boolean b=1 =a==b;
		boolean b=2 =b==c;
		boolean b=3 =a==c;
		boolean b4 =b1 || b2 || b3;
		System.out.println(b4);
		System.out.println(a==b || b==c ||a==c);
    }
}
