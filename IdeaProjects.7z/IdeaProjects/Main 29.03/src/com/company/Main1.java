package com.company;

import jdk.swing.interop.SwingInterOpUtils;

public class Main1 {
    public static void main(String[] args) {
        char c1 = '\u27FF';
        char c2 = '\u261B';
        String s = "" + c1 + c2;

        System.out.println(s);
        //сравнение
        String s1 = "first";
        String s2 = "firsa";
        int i = s1.compareTo(s2);
        System.out.println(i);

        //Конкатенация
        s1 = s1.concat(s2);
        System.out.println(s1);





    }
}