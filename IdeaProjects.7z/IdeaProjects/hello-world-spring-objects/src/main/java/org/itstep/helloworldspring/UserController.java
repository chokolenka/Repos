package org.itstep.helloworldspring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController// он вывел в json
public class UserController {

    @Autowired// автоприсоединение
    UserService userService;

    @RequestMapping("/")// отображение запроса
    public String index(){
        return "index";
    }

    @RequestMapping("/users")// отображение запроса
    public List<User> getUsers(){
        return userService.getUsers();
    }

    @RequestMapping("/user/{id}")// отображение запроса
    public User getUserById(@PathVariable Long id){
        return userService.getUserById(id);
    }

    @RequestMapping("/user")// отображение запроса
    public User getUserById2(@RequestParam(name ="id") Long id) {
        return userService.getUserById(id);
    }

}
