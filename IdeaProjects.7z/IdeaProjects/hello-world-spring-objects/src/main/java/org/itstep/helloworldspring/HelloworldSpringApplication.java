package org.itstep.helloworldspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloworldSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(HelloworldSpringApplication.class, args);
    }

}
