package org.itstep.helloworldspring;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {
    List<User> users = new ArrayList<>(){{
        add(new User(1L, "admin","admin", "admin@gmail.com"));
        add(new User(2L, "admin","admin", "serv@gmail.com"));
        add(new User(3L, "admin","admin", "admins@gmail.com"));
    }};

    public List<User> getUsers() {// вернуть пользователей
        return users;
    }
     public User getUserById(Long id) {
        User user = users
                .stream()// создали поток
                .filter(u->u.getId()==id)
                .findFirst(). orElse(null );// если нашел с двумя одинаковыми id
         return user;
     }

}
