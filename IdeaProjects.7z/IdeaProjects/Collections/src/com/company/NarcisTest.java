package com.company;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class NarcisTest {
    @Test
    void is_narc_dec_num() {
        int [] arr={0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 153, 370};
        for (int i=0; i<arr.length; i++)
        Assertions.assertTrue(Narcis.is_narc_dec_num(370));
        //Assertions.assertTrue(Narcis.is_narc_dec_num(369));
        //Assertions.assertEquals(true, Narcis.is_narc_dec_num(370));
    }
}