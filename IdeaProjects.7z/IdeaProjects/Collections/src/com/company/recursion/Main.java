package com.company.recursion;

public class Main {
    static int sum = 0;

    public static void main(String[] args) {
        recurse();
        recurse(0);
        sum(0);
        System.out.println(sum);
    }
    public static void recurse() {
        //System.out.println("hi");
        //recurse();

    }

    // как выйти из рекурсии
    public static void recurse(int n){
        if (n==5) return;
        //System.out.println("hi"+n);
        //recurse(n+1);
    }

    public static void sum(int n){
        if(n>10) return;
        sum+=n;
        sum(n+1);
    }

}
