package com.company;

import java.util.Arrays;

public class Array2D {
    public static void main(String[] args) {
        int nrows=3;
        int ncols=4;
        int[][] arr = new int[nrows][ncols]; // Строк, столбцов
        //arr[0][0] = 1;
        for (int i=0; i<nrows; i++)
            for (int j=0; j<ncols; j++)
                arr[i][j] = j+1+i*ncols;

        for (int i=0; i<nrows; i++)
            System.out.println(Arrays.toString(arr[i]));
        System.out.println();

        for (int i=0; i<nrows; i++)
            for (int j=0; j<ncols; j++)
                arr[i][j]+= 2;

        for (int i=0; i<nrows; i++)
            System.out.println(Arrays.toString(arr[i]));

        // вывести все элементы массива в одну строчку

        for (int i=0; i<nrows; i++)
            for (int j=0; j<ncols; j++)
                System.out.print(arr[i][j]+" ");

            // подстановочные знаки
        boolean  state= true;
        int count =3;
        double temp =36.6;
        String s = "Строка";
        System.out.printf ("Погода солнечная: %b, день: %d, температура: %.2f, строка: %s%n", state, count, temp, s);
    }
}
