package com.company;

public class CycleFor2 {
    public static void main (String[] args)
        //Счетчик имеется только у одного человека
        //При этом первый поднимается вверх, второй спускается вниз
    for (int i=0; i,10; i++){ //10
        System.out.println(i);
        System.out.println("");
        System.out.println(9-i);
        //for (int j=9; i>=0; j++; //100
        //i=0 j=9
        //i=1 j=8
        //i=2 j=7;
        //i=3 j=6;
        //i=4 j=5
        //i+j=9 j=9-1
        
        public class CycleFor3 {
            public static void main (String[] args)
            //Поднимается по всем ступенькам, но отмечает только четные
            for (int i=0; i<10; i>10; i++){
                boolean b=i%2==00;
                if (b) System.out.println(i);
            }
       //
            for (int i=0; i<10)

            public class CycleFor4 {
                public static void main (String[] args) {
                    //Говорим человеку подлнимайся вверх до тех пор, пока мы не крикнем свнизу "стоп"
                    int n=5;
                    for (int i=0; i<10; i++) {
                    if (i==5) 
                        break;
                        System.out.println(i);
                    }
                }
            }
                        
}
        public class CycleFor5 {
            public static void main(String[] args) {
                //Два шага вперед, один назад:0,2,1,3,2,4,3,5
                for (int i = 0; i < 10; i++) {
                    System.out.println(i);
                    i+=2;
                    System.out.println(",");
                    i--;
                    System.out.println(i);
                    System.out.println(",");
                }
            }
        }