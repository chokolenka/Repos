INSERT INTO users (username, password, email) VALUES ('admin', 'admin', 'admin@gmail.com');
INSERT INTO users (username, password, email) VALUES ('guest', 'guest', 'guest@gmail.com');
INSERT INTO users (username, password, email) VALUES ('user', 'user', 'user@gmail.com');