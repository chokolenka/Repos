package com.company.tests;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DemoTest {
    @Test
    public void getMissing(){
        assertEquals(5,Demo.getMissing(new int []{3, 2, 4, 6, 1}));

    }

}