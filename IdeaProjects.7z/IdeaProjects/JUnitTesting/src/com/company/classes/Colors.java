package com.company.classes;

public enum Colors{Black,Gray,Red,Yellow}
