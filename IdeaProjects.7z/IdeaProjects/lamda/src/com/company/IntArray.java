package com.company;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

    public class IntArray {
        static int count = 1000;

        public static void main(String[] args) {
            int[] arr = fillRandom();
            //printDivisible(arr);
            System.out.println(Arrays.toString(sortAsc(arr)));
            System.out.println(Arrays.toString(sortDesc(arr)));
        }

        public static int[] fillOrder() {
            return IntStream.range(1, count + 1).toArray();
        }

        public static int[] fillRandom() {
            Random random = new Random();
            //count=10    0....10
            return IntStream.generate(() -> random.nextInt(count) + 1)
                    .distinct()//убираем одинаковые
                    .limit(10)
                    .toArray();
        }

        public static void print(int[] arr) {
            System.out.println(

                    Arrays.stream
                            (arr)//из массива в поток

                            .mapToObj(String::valueOf) //из потока целых чисел переобразовываем в строки
                            .collect(Collectors.joining(", "))// собираем эти строки в одну
            );
        }

         static void printEven(int[] arr) {
            String s =
                    Arrays.stream
                            (arr)
                            .filter(i -> i % 2 == 0)
                            .mapToObj(String::valueOf)
                            .collect(Collectors.joining(", "));
            System.out.println(s);
        }

        //вывести все числа которые делятся на 3, 5, 11

         static void printDivisible(int[] arr) {
            long count =
                    Arrays.stream
                            (arr)
                            .filter(i ->i%3==0&&i%5==0&&i%11==0)
                            .count();
            System.out.println(count);
        }

         static int[] sortAsc(int[] arr){
            int[]result = Arrays.stream(arr)
                    .sorted()
                    .toArray();
            return result;
        }

        static int[] sortDesc(int[] arr){
            int[]result = Arrays.stream(arr)
                    .boxed()
                    .sorted(Comparator.reverseOrder())
                    .mapToInt(Integer::intValue )
                    .toArray();
            return result;
        }
    }
