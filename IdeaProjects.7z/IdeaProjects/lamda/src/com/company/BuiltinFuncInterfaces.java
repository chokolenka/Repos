package com.company;

import java.util.Comparator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class BuiltinFuncInterfaces {
    public static void main(String[] args) {
        // -> лямбда
        // Придикат// на входе объект - а на выходе true или false !!!
        // два аргумента на входе и выходе
        int n =2;
        Predicate<Integer> isPositive = i->i>0;
        System.out.println(isPositive.test(2));// positive объект
        Predicate<Integer>isZero = i->i==0;
        System.out.println(isZero.test(n));
        Predicate<Integer>isNegative = isPositive.or(isZero).negate();
        System.out.println(isZero.test(n));

        //Функция принимает один аргумент на выходе
        // один аргумент( один объект на вход и один на выход)  !!!

        Function<Person, String> getName = Person::getName;
        Person person = new Person ("name", "surname");
        System.out.println(getName.apply(person));
        Function<String,Character> firstChar = s->s.charAt(0);
        System.out.println(firstChar.apply("String"));

        // Поставщик
        Supplier<Person> supplier =Person::new;
        // создаем объект
        person = supplier.get();
        System.out.println(person.getName()); // выдаст null

        // Потребитель
        Consumer<Person> greeting = p-> System.out.println("Hello,"+p.getName());
        person = new Person("name", "surname");
        greeting.accept(person);

        // Сравниватель
        Comparator<Person> comparator = (p1,p2) -> p1.getName().compareTo(p2.getName());
        Person person1 = new Person("John", "Doe");
        Person person2 = new Person("Alice", "Krag");
        System.out.println(comparator.compare(person1,person2));

        //
    }
    // возвращает переменную булевского типа
    boolean isPositive(Integer i) {// positive метод
        if (i>0) return true;
        else return false;
    }
}
