 package  com.company;
public class Cycles{
    public static void main(String[]args){
        //Поднимаемся по ступенькам с 1-й по 9-ю

        for (int i=1;i<=9;i++)
            System.out.println(i);
        for (int i=1;i<=9;i++)
            System.out.println(i);
    }
}
