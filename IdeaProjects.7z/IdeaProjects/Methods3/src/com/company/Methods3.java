package com.company;
public class Methods3 {
    public static void main(String[] args) {
        System.out.println(factorial(4));
        System.out.println(factorial(3));
        System.out.println(isEven(3));
        int a=1, b=2;
        int temp;
        temp = a; a=b; b=temp;
        System.out.printf("a=%d, b=%d", a,b);
    }
    /*
    1!=1; 2!=2;3!=6; 4!=1*2*3*4=24;
    */
    static int  factorial(int n){
        int result=1;
        for (int i=1; i<=n; i++)
            result*=i;
        return result;
    }
    static boolean isEven(int n) {
        if (n%2==0) return true;
        else return false;
    }
    static int max(int a,int b){
        if (b>=a) return b;
        else return a;
    }

}

