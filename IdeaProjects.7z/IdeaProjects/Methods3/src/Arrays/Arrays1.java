package arrays;

import java.util.Arrays;
import java.util.Random;

//Class = fields, methods
public class Arrays1 {
    static int size = 10;
    static int[] arr = new int[size];

    public static void main(String[] args) {
        fillROrder();
        System.out.println(Arrays.toString(arr));
        System.out.println(max());
    }

    static void fillROrder(){
        //Заполнить по порядку числами 1,2,...,10
        for (int i=1; i<=arr.length; i++)
            arr[i-1] = arr.length-i+1;
    }

    static void fillRandom(){
        //Заполнить случайными двузначными числами
        Random random = new Random();
        for (int i=1; i<=arr.length; i++)
            arr[i-1] = random.nextInt(90)+10;
    }

    static int sum(){
        int sum = 0;
        for (int i=0; i<arr.length; i++)
            sum+=arr[i];
        return sum;
    }

    static int max(){
        //int max=0;
        //int max = Integer.MIN_VALUE;
        int max = arr[0];
        for (int i=0; i<arr.length; i++){
            boolean b = arr[i]>max;
            if (b) max=arr[i];
        }

        return max;
    }
}