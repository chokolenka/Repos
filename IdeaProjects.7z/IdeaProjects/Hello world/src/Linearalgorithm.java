public class Linearalgorithm {
    public static void main(String[] args) {
        System.out.println("Wake up");
        System.out.println("Get up");
        System.out.println("Make the bed");
        System.out.println("Get dressed");
        System.out.println("Drink a glass of water");
        System.out.println("Brush teeth");
    }
    }