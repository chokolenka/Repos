public class Branchedalgorithm {
    public static void main(String[] args) {
        int points = 70;
        if (points<30)
            System.out.println("Your mark is 3");
        else if (points<50)
            System.out.println("Your mark is 4");
        else
            System.out.println("Your mark is 5");
    }
}
