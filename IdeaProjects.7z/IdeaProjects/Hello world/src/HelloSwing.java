import javax.swing.*;

public class HelloSwing {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null,"Hello,world!");
    }

}
