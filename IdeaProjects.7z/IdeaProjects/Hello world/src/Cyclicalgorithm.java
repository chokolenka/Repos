public class Cyclicalgorithm {
    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            System.out.print("Fall forward, ");
            System.out.print("Push up, ");
            System.out.println("Stand up");
        }
    }
}
