public class RunAll {
    public static void main(String[] args) {
        publicclassHelloworld.main(args);
        HelloSwing.main(args);

    }
}
