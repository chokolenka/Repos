INSERT INTO jewelry (name, color, price, price_new, material_id) VALUES ('French Pave Diamond Engagement Ring in Platinum (1/4 ct. tw.)', 'Platinum', 175000,131250,1);
INSERT INTO jewelry (name, color, price, price_new, material_id) VALUES ('Petite Solitaire Engagement Ring in Platinum', 'White', 89000,66750,2);

insert into material(name) values ('Platinum');
insert into material(name) values ('White');
insert into material(name) values ('Yellow');
insert into material(name) values ('Rose');