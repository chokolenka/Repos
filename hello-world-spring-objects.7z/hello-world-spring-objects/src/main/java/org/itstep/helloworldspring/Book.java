package org.itstep.helloworldspring;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


    @Data // добавляет геттеры и сеттеры
    //@Entity // отображение класса на таблицу Hibernate спящий режим
    @AllArgsConstructor // конструктор с параметрами - инициализирующий
    @NoArgsConstructor // контсруктор без параметров ( по умолчанию)
    //@Table(name="books")  // НАЗВАНИЕ ТАБЛИЦЫ
    public class Book {
        //@Id
//        @Column(name="id")
//        @GeneratedValue(strategy=GenerationType.IDENTITY)
        private Long id;
        private String title;
        private String isbn;
        private int year;
        private String[] authors;
    }

